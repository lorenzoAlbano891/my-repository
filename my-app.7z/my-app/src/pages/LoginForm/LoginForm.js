import React, { useState } from "react";
import { Container, Row, Col, Form, Button } from "react-bootstrap";
import "./LoginForm.css";
import userlog from "../../assets/userlog.png";

function LoginForm({ Login, error }) {
  const [details, setDetails] = useState({ email: "", password: "" });
  const submitHandler = (e) => {
    e.preventDefault();
    Login(details);
  };
  return (
    <>
      <Container className="mt-5" onSubmit={submitHandler}>
        <Row>
          <Col lg={6} md={6} sm={12} className="text-center">
            <img className="icon-img" src={userlog} alt="user-icon" />
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                  onChange={(e) =>
                    setDetails({ ...details, email: e.target.value })
                  }
                  value={details.email}
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Control
                  type="password"
                  placeholder="Password"
                  onChange={(e) =>
                    setDetails({ ...details, password: e.target.value })
                  }
                  value={details.password}
                />
              </Form.Group>
              <div className="d-grid gap-2">
                <Button variant="primary" size="lg" type="submit">
                  Login
                </Button>
              </div>
              <div>
                <a href="#">
                  <small className="reset">Password Reset</small>
                </a>
              </div>
            </Form>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default LoginForm;
