import React, { useState } from "react";
import PersonalInfoRow from "../../components/PersonalInfoRow";
import "./EditCareer.css";

function EditCareer() {
  const [user, setUser] = useState({
    activity1: "First Activity - lorem ipsum",
    activity2: "Second Activity - lorem ipsum",
    activity3: "Third Activity - lorem ipsum",
    activity4: "Fourth Activity - lorem ipsum",
    activity5: "Fifth Activity - lorem ipsum",
  });

  const { activity1, activity2, activity3, activity4, activity5 } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    alert("test onSubmit ok");
  };

  return (
    <div className="container">
      <div className="w-75 mx-auto shadow p-5">
        <h2 className="text-center mb-4">Edit CV records</h2>
        <form onSubmit={(e) => onSubmit(e)}>
          <PersonalInfoRow />
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Your activity 1"
              name="activity1"
              value={activity1}
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Your activity 2"
              name="activity2"
              value={activity2}
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Your activity 3"
              name="activity3"
              value={activity3}
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Your activity 4"
              name="activity4"
              value={activity4}
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Your activity 5"
              name="activity5"
              value={activity5}
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <button className="btn btn-warning ">Update User</button>
        </form>
      </div>
    </div>
  );
}

export default EditCareer;
