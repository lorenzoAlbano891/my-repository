import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import "./Home.css";
import PersonalInfoRow from "../../components/PersonalInfoRow";
import JobExperienceRow from "../../components/JobExperienceRow";
function Home() {
  return (
    <Container fluid="md">
      <PersonalInfoRow />
      <Row>
        <Col>
          <JobExperienceRow />
        </Col>
      </Row>
    </Container>
  );
}

export default Home;
