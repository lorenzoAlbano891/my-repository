import React, { useState } from "react";
import {
  Form,
  Container,
  Row,
  Col,
  ListGroup,
  FloatingLabel,
} from "react-bootstrap";
import "./Offers.css";
import Buttons from "../../components/Buttons";

function Offers() {
  const [validated, setValidated] = useState(false);

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };

  return (
    <Container>
      <Row>
        <Col className="p-5">
          <ListGroup as="ul" className="mb-3">
            <ListGroup.Item as="li" active>
              Fill every fields and I will answer soon!
            </ListGroup.Item>
          </ListGroup>
          <Form noValidate validated={validated} onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="validationCustom01">
              <Form.Label>Your Company name</Form.Label>
              <Form.Control
                required
                type="text"
                placeholder="Enter your Company name"
              />
              <Form.Control.Feedback type="invalid">
                Please type your Comany name
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                required
                type="email"
                placeholder="Enter your e-mail"
              />
              <Form.Control.Feedback type="invalid">
                Please type your email address
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicNumber">
              <Form.Label>Phone Number</Form.Label>
              <Form.Control
                type="tel"
                id="phone"
                required
                placeholder="Enter your Phone number"
              />
              <Form.Text className="text-muted">
                I'll never share your contacts with anyone else.
              </Form.Text>
              <Form.Control.Feedback type="invalid">
                Please type your phone number
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicQuestion">
              <Form.Label>Any Question?</Form.Label>
              <FloatingLabel
                controlId="floatingTextarea2"
                label="Leave a question here"
              >
                <Form.Control
                  as="textarea"
                  placeholder="Leave a comment here"
                  style={{ height: "100px" }}
                />
              </FloatingLabel>
              <Form.Text className="text-muted">
                Feel free to ask what you need
              </Form.Text>
            </Form.Group>
            <Form.Group
              className="mb-4 btn btn-lg btn-outline-primary w-100"
              controlId="formBasicCheckbox"
            >
              <Form.Check type="checkbox" label="Check me out" />
            </Form.Group>
            <Buttons />
          </Form>
        </Col>

        <Col className="col-dx mt-5"></Col>
      </Row>
    </Container>
  );
}

export default Offers;
