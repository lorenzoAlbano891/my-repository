import React from "react";
import { Form, Button } from "react-bootstrap";
function Buttons() {
  return (
    <>
      <Button
        className="btn btn-lg btn-outline-primary w-100"
        variant="warning"
        type="submit"
      >
        Submit
      </Button>
    </>
  );
}

export default Buttons;
