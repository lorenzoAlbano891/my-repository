import React from "react";
import { Navbar, Container, Nav, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import "./HeaderNav.css";

function HeaderNav({ Logout }) {
  return (
    <Navbar bg="dark" variant="dark">
      <Container>
        <Navbar.Brand as={Link} to="/">
          My PersonalCV
        </Navbar.Brand>
        <Nav className="me-auto">
          <Nav.Link as={Link} to="/">
            Home
          </Nav.Link>
          <Nav.Link as={Link} to="/offers">
            Offers
          </Nav.Link>
          <Nav.Link as={Link} to="/edit">
            Edit
          </Nav.Link>
          <span>
            <Button onClick={Logout}>Logout</Button>
          </span>
        </Nav>
      </Container>
    </Navbar>
  );
}

export default HeaderNav;
