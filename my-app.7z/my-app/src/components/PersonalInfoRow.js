import React, { useState } from "react";
import "./PersonalInfo.css";
import { Row, Col } from "react-bootstrap";
import lorenzo from "../assets/lorenzo.jpeg";
import phone from "../assets/phone.png";

function PersonalInfoRow() {
  const [personalInfo, setPersonalInfo] = useState({
    name: "Lorenzo Albano",
    phone: "333-8221013",
    email: "lorenzo.albano89@gmail.com",
  });

  return (
    <div className="personal_info">
      <Row>
        <Col sm>
          <img src={lorenzo} className="img" alt="image" />
        </Col>
        <Col>
          <h3>{personalInfo.name}</h3>
          <h3>Cell: {personalInfo.phone}</h3>
          <h3>E-mail: {personalInfo.email}</h3>
        </Col>
      </Row>
    </div>
  );
}

export default PersonalInfoRow;
