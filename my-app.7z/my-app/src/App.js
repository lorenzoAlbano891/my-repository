import React, { useState } from "react";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Offers from "./pages/Offers/Offers";
import Home from "./pages/Home/Home";
import EditCareer from "./pages/EditCareer/EditCareer";
import LoginForm from "./pages/LoginForm/LoginForm";
import HeaderNav from "./components/HeaderNav";
import "../node_modules/bootstrap/dist/css/bootstrap.css";

function App() {
  const publicUser = {
    email: "user@user.com",
    password: "123",
  };
  const [user, setUser] = useState({ email: "" });
  const [error, setError] = useState("");

  const Login = (details) => {
    console.log(details);
    if (
      details.email === publicUser.email &&
      details.password === publicUser.password
    ) {
      setUser({
        email: details.email,
      });
    } else {
      console.log("details do not match");
      setError("Details do not match");
    }
  };

  const Logout = () => {
    setUser({
      name: "",
      email: "",
    });
  };
  return (
    <BrowserRouter>
      {user.email != "" ? (
        <div className="App">
          <>
            <HeaderNav Logout={Logout} />
          </>
          <div>
            <Routes>
              <Route path="/login" element={<LoginForm />} />
              <Route path="/offers" element={<Offers />} />
              <Route path="/edit" element={<EditCareer />} />
              <Route path="/" element={<Home />} />
            </Routes>
          </div>
        </div>
      ) : (
        <div className="login-form">
          <LoginForm Login={Login} error={error} />
        </div>
      )}
    </BrowserRouter>
  );
}

export default App;

/*
return (
    <BrowserRouter>
      {user.email != "" ? (
        <div className="App">
          <>
            <HeaderNav Logout={Logout} />
          </>
          <div>
            <Routes>
              <Route path="/login" element={<LoginForm />} />
              <Route path="/offers" element={<Offers />} />
              <Route path="/edit" element={<EditCareer />} />
              <Route path="/" element={<Home />} />
            </Routes>
          </div>
        </div>
      ) : (
        <div className="login-form">
          <LoginForm Login={Login} error={error} />
        </div>
      )}
    </BrowserRouter>
  );
*/
